String aapt = getApplicationInfo().nativeLibraryDir + "/libaapt.so";
        Process pr = null;
        try {
            pr = Runtime.getRuntime().exec(new String[] {aapt});
        } catch (IOException e) {
            e.printStackTrace();
        }
        String log = readInputStreem(pr.getErrorStream());
        textview.setText(log);